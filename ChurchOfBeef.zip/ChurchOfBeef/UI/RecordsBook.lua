ChurchOfBeef = ChurchOfBeef or {}
local COB = ChurchOfBeef

-- Player-opened Quiet identity/history (Bible §14.2). Theatrical parchment
-- superlatives (Law 10 / §10.9 / §19.3). Not a sortable ladder. Toggle / Show /
-- Hide only. Hide remounts a missing OnHide before rememberSpecial
-- then frame:Hide(). Show remounts a missing OnHide, then paint /
-- frame:Show(). Existing-frame Init remounts a missing OnHide, then
-- rememberSpecial. OnHide remounts rememberSpecial so ESC still
-- re-lists. Do not reset pageIndex. The UI never records outcomes,
-- never narrates, and never tells jokes.
--
-- Composed tome: charcoal title band, two parchment leaves meeting at
-- center ±1, charcoal footer tabs (Previous / Victories / Rivalries /
-- Martyrs / Next). Page title lives on the left leaf. Medallions stride
-- with the body (Theme.Space.lg). Dress resolves through Theme. Chrome
-- title and page titles use FontPath("label") — serif small-caps.
-- Display/blackletter is reserved for proclamation headlines and fighter
-- names; page titles are neither. Body and moment scripture use
-- FontPath("body") at Theme.FontSize.body (charcoal on parchment).
-- Chrome title is gold on the charcoal band at FontSize.headline.
-- Page titles stay oxblood on parchment (U-M). Opaque LeftLeafFill /
-- RightLeafFill sit under letterboxed tome_records so GoldEdge cannot
-- leak through the spread margin. Leaves use Texture("tome_records")
-- (stock fallback until the spread art lands). Entry medallions use
-- Texture("seal_papal") on a fixed slot pool created once; paint() only
-- shows/hides. Ribbons use Texture("ribbon_bookmark").
-- RecordsBook.toRoman wraps Common.RomanNumeral and returns "" when
-- Common returns nil, matching the old public contract.
local RecordsBook = {
  MODE = "QUIET",
}
COB.RecordsBook = RecordsBook

local FRAME_NAME = "ChurchOfBeefRecordsBook"
local MEDALLION_POOL = 8

local PAGE_TITLES = {
  "Most Sanctioned Victories",
  "Longest Streak",
  "Most Successful Defenses",
  "The Iron Chin",
  "Greatest Rivalry",
  "Famous Upsets",
  "The Undefeated",
  "The Glorious Martyr",
  "Tournament Champions",
}

local pageIndex = 1

local function deepcopy(value)
  if type(value) ~= "table" then return value end
  local out = {}
  for k, v in pairs(value) do
    out[deepcopy(k)] = deepcopy(v)
  end
  return out
end

local function themeColor(role)
  local Theme = COB.Theme
  if not (Theme and type(Theme.Color) == "function") then return nil end
  return Theme:Color(role)
end

local function themeFont(role)
  local Theme = COB.Theme
  if not (Theme and type(Theme.FontPath) == "function") then return nil end
  return Theme:FontPath(role)
end

local function themeTexture(name)
  local Theme = COB.Theme
  if not (Theme and type(Theme.Texture) == "function") then return nil end
  return Theme:Texture(name)
end

local function space(key, fallback)
  local sizes = COB.Theme and COB.Theme.Space
  if type(sizes) == "table" and type(sizes[key]) == "number" then
    return sizes[key]
  end
  return fallback
end

local function themeFontSize(key, fallback)
  local sizes = COB.Theme and COB.Theme.FontSize
  if type(sizes) == "table" and type(sizes[key]) == "number" then
    return sizes[key]
  end
  return fallback
end

local function fill(tex, r, g, b, a)
  if not tex then return end
  if tex.SetColorTexture then
    tex:SetColorTexture(r, g, b, a)
  elseif tex.SetVertexColor then
    tex:SetVertexColor(r, g, b, a)
  end
  tex._cobColor = { r = r, g = g, b = b, a = a }
end

local function fillRole(tex, role, a)
  if not tex then return end
  local r, g, b = themeColor(role)
  if type(r) ~= "number" then return end
  fill(tex, r, g, b, a or 1)
  tex._cobColorRole = role
end

local function applyInk(fs, role, a)
  if not fs then return end
  local r, g, b = themeColor(role)
  if type(r) ~= "number" then return end
  if fs.SetTextColor then fs:SetTextColor(r, g, b, a or 1) end
  fs._cobColor = { r = r, g = g, b = b, a = a or 1 }
  fs._cobColorRole = role
end

local function applyTexture(tex, name)
  if not tex then return false end
  local path = themeTexture(name)
  tex._cobTextureName = name
  tex._cobTexture = path
  if type(path) ~= "string" or not tex.SetTexture then return false end
  local ok = pcall(tex.SetTexture, tex, path)
  return ok and true or false
end

local function applyFont(fs, template, role, size)
  if not fs then return end
  local path = role and themeFont(role) or nil
  local used = false
  if path and fs.SetFont then
    local ok, applied = pcall(fs.SetFont, fs, path, size or themeFontSize("name", 16), "")
    used = ok and applied and true or false
  end
  if not used and fs.SetFontObject then
    local font = template
    if type(template) == "string" then font = _G[template] end
    if font then pcall(fs.SetFontObject, fs, font) end
  end
  fs._cobFontRole = role
  fs._cobFontPath = path
  fs._cobFontSize = size
end

-- Public alias keeps the old contract: "" on invalid input. Common.RomanNumeral
-- returns nil+err for the same cases; floor first so 14.9 still paints XIV.
local function toRoman(n)
  if type(n) ~= "number" then return "" end
  local roman = COB.Common and COB.Common.RomanNumeral
  if type(roman) ~= "function" then return "" end
  local s = roman(math.floor(n))
  if type(s) == "string" then return s end
  return ""
end

RecordsBook.toRoman = toRoman

local function displayCount(n)
  if type(n) ~= "number" then n = 0 end
  return toRoman(n)
end

local function applyParchment(tex)
  if not tex then return end
  if tex.SetHorizTile then tex:SetHorizTile(false) end
  if tex.SetVertTile then tex:SetVertTile(false) end
  if applyTexture(tex, "tome_records") then
    -- Generated masters keep a transparent production safety margin. Crop it
    -- here so the parchment reaches the leaf edges instead of painting a pale
    -- rectangle inside another pale rectangle.
    if tex.SetTexCoord then pcall(tex.SetTexCoord, tex, 0.10, 0.90, 0.10, 0.90) end
    return
  end
  fillRole(tex, "parchment", 0.94)
end

local function tomeHeight()
  local parent = UIParent
  local h = parent and parent.GetHeight and parent:GetHeight()
  if type(h) == "number" and h > 0 then
    return math.floor(h * 0.7 + 0.5)
  end
  return 480
end

local function dressDarkPlate(btn)
  if not btn then return end
  local plate = btn._cobPlate
  if not plate then
    plate = btn:CreateTexture(nil, "ARTWORK")
    if plate.SetAllPoints then plate:SetAllPoints(btn) end
    btn._cobPlate = plate
  end
  fillRole(plate, "charcoal")
  btn._cobPlateRole = "charcoal"
end

local function labelButton(button, text, template)
  if not button then return end
  local fs = button:CreateFontString(nil, "OVERLAY", template or "GameFontNormal")
  applyFont(fs, template or "GameFontNormal", "label", 14)
  applyInk(fs, "gold")
  if fs.SetAllPoints then fs:SetAllPoints(button) end
  if fs.SetText then fs:SetText(text) end
  if button.SetFontString then button:SetFontString(fs) end
  button:SetText(text)
  dressDarkPlate(button)
end

local function dressRibbon(btn)
  if not btn then return end
  local path = themeTexture("ribbon_bookmark")
  btn._cobTextureName = "ribbon_bookmark"
  btn._cobTexture = path
  if type(path) == "string" and btn.SetNormalTexture then
    pcall(btn.SetNormalTexture, btn, path)
  end
  dressDarkPlate(btn)
end

local function dressMedallion(slot)
  if not slot then return end
  applyTexture(slot, "seal_papal")
  local r, g, b = themeColor("gold")
  if type(r) == "number" and slot.SetVertexColor then
    slot:SetVertexColor(r, g, b, 1)
  end
  slot._cobColorRole = "gold"
end

local function emptyPages()
  local pages = {}
  for i = 1, #PAGE_TITLES do
    pages[i] = { title = PAGE_TITLES[i], entries = {} }
  end
  return pages
end

local function longestWinStreak(gora)
  local current, longest = 0, 0
  local results = gora and gora.results
  if type(results) ~= "table" then return 0 end
  for i = 1, #results do
    local won = results[i].won
    if won == true then
      current = current + 1
      if current > longest then longest = current end
    elseif won == false then
      current = 0
    end
  end
  return longest
end

local function foughtCount(gora)
  local results = gora and gora.results
  if type(results) ~= "table" then return 0 end
  return #results
end

local function charName(characters, id)
  local row = characters[id]
  return row and row.name or nil
end

local function indexCharacters(list)
  local byId = {}
  if type(list) ~= "table" then return byId end
  for i = 1, #list do
    local row = list[i]
    if type(row) == "table" and type(row.id) == "number" then
      byId[row.id] = row
    end
  end
  return byId
end

-- OPEN_QUESTIONS #9: sitting-Lord victories after elevationAt. Prefer Store.
-- Same walk if the method is missing. Never a stored increment.
local function deriveDefenses(gora, elevationAt)
  if type(elevationAt) ~= "number" then return 0 end
  local results = gora and gora.results
  if type(results) ~= "table" then return 0 end
  local n = 0
  for i = 1, #results do
    local result = results[i]
    if result and result.won == true then
      local at = result.at
      if type(at) == "number" and at >= elevationAt then
        n = n + 1
      end
    end
  end
  return n
end

local function countDefenses(characterId, gora, humanId)
  if COB.Store and type(COB.Store.CountDefenses) == "function" then
    local n = COB.Store:CountDefenses(characterId)
    if type(n) == "number" then return n end
    return 0
  end
  if type(humanId) ~= "number" then return 0 end
  local human = COB.Store and COB.Store.GetHuman and COB.Store:GetHuman(humanId)
  local elevationAt = human and human.elevationAt
  return deriveDefenses(gora, elevationAt)
end

local function maxHolders(rows, key)
  local best = nil
  for i = 1, #rows do
    local v = rows[i][key]
    if type(v) == "number" and (best == nil or v > best) then
      best = v
    end
  end
  if best == nil or best < 1 then return {} end
  local holders = {}
  for i = 1, #rows do
    if rows[i][key] == best then
      holders[#holders + 1] = rows[i]
    end
  end
  return holders
end

local function pairKey(a, b)
  if a < b then return a, b else return b, a end
end

local function buildPages()
  local pages = emptyPages()
  if not (COB.Store and COB.Store.Snapshot) then return pages end
  local snap = COB.Store:Snapshot()
  local list = snap and snap.characters
  if type(list) ~= "table" then return pages end

  local byId = indexCharacters(list)
  local measured = {}
  for i = 1, #list do
    local ch = list[i]
    local gora = ch.gora
    if type(ch) == "table" and type(gora) == "table" then
      local wins = gora.wins
      local losses = gora.losses
      if type(wins) ~= "number" then wins = 0 end
      if type(losses) ~= "number" then losses = 0 end
      measured[#measured + 1] = {
        characterId = ch.id,
        name = ch.name,
        humanId = ch.humanId,
        wins = wins,
        losses = losses,
        streak = longestWinStreak(gora),
        fought = foughtCount(gora),
        gora = gora,
      }
    end
  end

  local function put(title, entries)
    for i = 1, #pages do
      if pages[i].title == title then
        pages[i].entries = entries
        return
      end
    end
  end

  local victoryRows = {}
  for i = 1, #measured do
    victoryRows[i] = {
      characterId = measured[i].characterId,
      name = measured[i].name,
      wins = measured[i].wins,
    }
  end
  put("Most Sanctioned Victories", maxHolders(victoryRows, "wins"))

  local streakRows = {}
  for i = 1, #measured do
    streakRows[i] = {
      characterId = measured[i].characterId,
      name = measured[i].name,
      streak = measured[i].streak,
    }
  end
  put("Longest Streak", maxHolders(streakRows, "streak"))

  local defenseRows = {}
  for i = 1, #measured do
    defenseRows[i] = {
      characterId = measured[i].characterId,
      name = measured[i].name,
      defenses = countDefenses(measured[i].characterId, measured[i].gora, measured[i].humanId),
    }
  end
  put("Most Successful Defenses", maxHolders(defenseRows, "defenses"))

  local chinRows = {}
  for i = 1, #measured do
    chinRows[i] = {
      characterId = measured[i].characterId,
      name = measured[i].name,
      fought = measured[i].fought,
    }
  end
  put("The Iron Chin", maxHolders(chinRows, "fought"))

  local pairMap = {}
  local pairList = {}
  for i = 1, #measured do
    local ch = measured[i]
    local heads = ch.gora.headToHeads
    if type(heads) == "table" then
      for h = 1, #heads do
        local row = heads[h]
        local oppId = row and row.opponentId
        if type(oppId) == "number" and oppId ~= ch.characterId then
          local lo, hi = pairKey(ch.characterId, oppId)
          local key = tostring(lo) .. ":" .. tostring(hi)
          local pairing = pairMap[key]
          if not pairing then
            pairing = { lo = lo, hi = hi, fights = 0, scoreLo = 0, scoreHi = 0 }
            pairMap[key] = pairing
            pairList[#pairList + 1] = pairing
          end
          local fights = row.fights
          if type(fights) ~= "number" then fights = 0 end
          if fights > pairing.fights then pairing.fights = fights end
          local wins = row.wins
          local losses = row.losses
          if type(wins) ~= "number" then wins = 0 end
          if type(losses) ~= "number" then losses = 0 end
          if ch.characterId == lo then
            pairing.scoreLo = wins
            pairing.scoreHi = losses
          else
            pairing.scoreHi = wins
            pairing.scoreLo = losses
          end
        end
      end
    end
  end
  local bestFights = nil
  for i = 1, #pairList do
    local n = pairList[i].fights
    if type(n) == "number" and (bestFights == nil or n > bestFights) then
      bestFights = n
    end
  end
  local rivalries = {}
  if type(bestFights) == "number" and bestFights >= 1 then
    for i = 1, #pairList do
      local pairing = pairList[i]
      if pairing.fights == bestFights then
        rivalries[#rivalries + 1] = {
          characterIdA = pairing.lo,
          characterIdB = pairing.hi,
          nameA = charName(byId, pairing.lo),
          nameB = charName(byId, pairing.hi),
          fights = pairing.fights,
          scoreA = pairing.scoreLo,
          scoreB = pairing.scoreHi,
        }
      end
    end
  end
  put("Greatest Rivalry", rivalries)

  local seenUpset = {}
  local upsets = {}
  for i = 1, #measured do
    local ch = measured[i]
    local results = ch.gora.results
    if type(results) == "table" then
      for r = 1, #results do
        local result = results[r]
        if result and result.famousUpset == true and type(result.opponentId) == "number" then
          local lo, hi = pairKey(ch.characterId, result.opponentId)
          local at = result.at
          if type(at) ~= "number" then at = 0 end
          local key = tostring(at) .. ":" .. tostring(lo) .. ":" .. tostring(hi)
          if not seenUpset[key] then
            seenUpset[key] = true
            local winnerId, loserId = ch.characterId, result.opponentId
            if result.won == false then
              winnerId, loserId = result.opponentId, ch.characterId
            end
            upsets[#upsets + 1] = {
              characterId = winnerId,
              opponentId = loserId,
              name = charName(byId, winnerId),
              opponentName = charName(byId, loserId),
              at = result.at,
            }
          end
        end
      end
    end
  end
  put("Famous Upsets", upsets)

  local unbeaten = {}
  for i = 1, #measured do
    local row = measured[i]
    if row.wins >= 1 and row.losses == 0 then
      unbeaten[#unbeaten + 1] = {
        characterId = row.characterId,
        name = row.name,
        wins = row.wins,
      }
    end
  end
  put("The Undefeated", unbeaten)

  local martyrRows = {}
  for i = 1, #measured do
    martyrRows[i] = {
      characterId = measured[i].characterId,
      name = measured[i].name,
      losses = measured[i].losses,
    }
  end
  put("The Glorious Martyr", maxHolders(martyrRows, "losses"))

  -- Tournament Champions: empty until tournaments exist. Do not invent an engine.
  put("Tournament Champions", {})

  return pages
end

local function bodyText(page)
  if type(page) ~= "table" or type(page.entries) ~= "table" or #page.entries == 0 then
    return "No entries recorded."
  end
  local lines = {}
  local title = page.title
  for i = 1, #page.entries do
    local e = page.entries[i]
    local line
    if title == "Greatest Rivalry" then
      line = string.format("%s  %s – %s  %s",
        e.nameA or "", displayCount(e.scoreA or 0), displayCount(e.scoreB or 0), e.nameB or "")
    elseif title == "Famous Upsets" then
      line = string.format("%s over %s", e.name or "", e.opponentName or "")
    elseif title == "The Undefeated" then
      line = e.name or ""
    elseif title == "Most Sanctioned Victories" then
      line = string.format("%s — %s", e.name or "", displayCount(e.wins or 0))
    elseif title == "Longest Streak" then
      line = string.format("%s — %s", e.name or "", displayCount(e.streak or 0))
    elseif title == "Most Successful Defenses" then
      line = string.format("%s — %s", e.name or "", displayCount(e.defenses or 0))
    elseif title == "The Iron Chin" then
      line = string.format("%s — %s", e.name or "", displayCount(e.fought or 0))
    elseif title == "The Glorious Martyr" then
      line = string.format("%s — %s", e.name or "", displayCount(e.losses or 0))
    else
      line = e.name or ""
    end
    if type(e.citation) == "string" and e.citation ~= "" then
      line = line .. "\n" .. e.citation
    end
    lines[#lines + 1] = line
  end
  return table.concat(lines, "\n")
end

local function localPlayerKey()
  if type(UnitName) ~= "function" then return nil end
  if not (COB.Names and COB.Names.Key) then return nil end
  return COB.Names.Key(UnitName("player"))
end

-- Local human honorifics only. No character match or no human bind → empty.
local function localHonorifics()
  local key = localPlayerKey()
  if not key then return {} end
  if not (COB.Store and COB.Store.Snapshot) then return {} end
  local snap = COB.Store:Snapshot()
  local list = snap and snap.characters
  if type(list) ~= "table" then return {} end
  local humanId
  for i = 1, #list do
    local ch = list[i]
    if type(ch) == "table" and COB.Names.Key(ch.name) == key then
      humanId = ch.humanId
      break
    end
  end
  if type(humanId) ~= "number" then return {} end
  local human = COB.Store.GetHuman and COB.Store:GetHuman(humanId)
  local raw = human and human.honorifics
  if type(raw) ~= "table" then return {} end
  local titles = {}
  for i = 1, #raw do
    if type(raw[i]) == "string" and raw[i] ~= "" then
      titles[#titles + 1] = raw[i]
    end
  end
  return titles
end

-- Location first, then Pope scripture when present. No invented copy.
local function momentLines()
  if not (COB.Store and COB.Store.GetMarkedMoments) then return {} end
  local moments = COB.Store:GetMarkedMoments()
  if type(moments) ~= "table" then return {} end
  local lines = {}
  for i = 1, #moments do
    local row = moments[i]
    if type(row) == "table" then
      local loc = row.location
      if type(loc) == "string" and loc ~= "" then
        lines[#lines + 1] = loc
      end
      local scripture = row.scripture
      if type(scripture) == "string" and scripture ~= "" then
        lines[#lines + 1] = scripture
      end
    end
  end
  return lines
end

local function identityText(rows)
  if type(rows) ~= "table" or #rows == 0 then return "None recorded." end
  return table.concat(rows, "\n")
end

local function guildIdentity()
  if type(GetGuildInfo) ~= "function" then return nil, nil end
  local ok, guildName, guildRole = pcall(GetGuildInfo, "player")
  if not ok then return nil, nil end
  if type(guildName) ~= "string" or guildName == "" then guildName = nil end
  if type(guildRole) ~= "string" or guildRole == "" then guildRole = nil end
  return guildName, guildRole
end

local function archiveGoraCount(characters)
  if type(characters) ~= "table" then return 0 end
  local seen, count = {}, 0
  for i = 1, #characters do
    local ch = characters[i]
    local results = type(ch) == "table" and ch.gora and ch.gora.results
    if type(results) == "table" and type(ch.id) == "number" then
      for j = 1, #results do
        local row = results[j]
        local opponentId = type(row) == "table" and row.opponentId
        if type(opponentId) == "number" then
          local lo, hi = pairKey(ch.id, opponentId)
          local key = table.concat({
            tostring(row.at or ""), tostring(lo), tostring(hi), tostring(row.ruling or ""),
          }, ":")
          if not seen[key] then
            seen[key] = true
            count = count + 1
          end
        end
      end
    end
  end
  return count
end

local function overviewModel()
  local snap = COB.Store and COB.Store.Snapshot and COB.Store:Snapshot() or {}
  local characters = type(snap.characters) == "table" and snap.characters or {}
  local humans = type(snap.humans) == "table" and snap.humans or {}
  local ceremonyLog = type(snap.ceremonyLog) == "table" and snap.ceremonyLog or {}
  local markedMoments = type(snap.markedMoments) == "table" and snap.markedMoments or {}

  local guildName, guildRole = guildIdentity()
  local playerName = type(UnitName) == "function" and UnitName("player") or nil
  if type(playerName) ~= "string" or playerName == "" then playerName = "Unknown character" end
  local playerKey = COB.Names and COB.Names.Key and COB.Names.Key(playerName) or nil
  local playerCharacter
  if playerKey then
    for i = 1, #characters do
      local row = characters[i]
      if type(row) == "table" and COB.Names.Key(row.name) == playerKey then
        playerCharacter = row
        break
      end
    end
  end

  local playerHuman
  if playerCharacter and type(playerCharacter.humanId) == "number" then
    for i = 1, #humans do
      if humans[i].id == playerCharacter.humanId then
        playerHuman = humans[i]
        break
      end
    end
  end

  local rankTitle = "Not entered in the archive"
  if playerHuman and type(playerHuman.rankId) == "number"
      and COB.Ranks and type(COB.Ranks.Title) == "function" then
    rankTitle = COB.Ranks.Title(playerHuman.rankId)
  end

  local honorifics = "None recorded"
  if playerHuman and type(playerHuman.honorifics) == "table" and #playerHuman.honorifics > 0 then
    honorifics = table.concat(playerHuman.honorifics, ", ")
  end

  local record = "No sanctioned record"
  if playerCharacter and type(playerCharacter.gora) == "table" then
    local wins = type(playerCharacter.gora.wins) == "number" and playerCharacter.gora.wins or 0
    local losses = type(playerCharacter.gora.losses) == "number" and playerCharacter.gora.losses or 0
    if wins > 0 or losses > 0 then record = string.format("%d–%d", wins, losses) end
  end

  local runtime = COB.Runtime and COB.Runtime.Snapshot and COB.Runtime:Snapshot() or {}
  local state = "Quiet"
  if runtime.awaitingPope == true then
    state = "Awaiting the Pope"
  elseif runtime.state == "ASSEMBLY" then
    state = "Gathering"
  elseif runtime.state == "RITE" then
    state = runtime.riteType and ("Rite — " .. runtime.riteType) or "Rite"
  elseif runtime.state == "CONSEQUENCE" then
    state = runtime.riteType and ("Consequence — " .. runtime.riteType) or "Consequence"
  end

  local decree = COB.Decree and COB.Decree.Get and COB.Decree:Get() or nil
  local decreeLine = decree and decree.line or "No active Decree"
  local decreeFlavor = decree and decree.flavor or ""

  local rosterValue = "—"
  local roster = COB.Roster
  if roster and roster.IsReady and roster:IsReady() and roster.GetOccupantCount then
    rosterValue = tostring(roster:GetOccupantCount())
  end

  local latestCeremony = "No ceremony recorded"
  local ceremony = ceremonyLog[#ceremonyLog]
  if type(ceremony) == "table" then
    local name = type(ceremony.text) == "string" and ceremony.text or ceremony.type
    if type(name) == "string" and name ~= "" then latestCeremony = name end
  end

  local latestMoment = "No marked moment recorded"
  local moment = markedMoments[#markedMoments]
  if type(moment) == "table" then
    local memory = type(moment.scripture) == "string" and moment.scripture or moment.location
    if type(memory) == "string" and memory ~= "" then latestMoment = memory end
  end

  local className = playerCharacter and playerCharacter.class or "Not entered in the archive"
  local classKey = type(className) == "string" and string.upper(className):gsub("%s", "") or nil

  return {
    guildName = guildName or "Church of Beef",
    guildRole = guildRole or "Unavailable",
    state = state,
    decreeLine = decreeLine,
    decreeFlavor = decreeFlavor,
    roster = rosterValue,
    ceremonies = tostring(#ceremonyLog),
    goras = tostring(archiveGoraCount(characters)),
    moments = tostring(#markedMoments),
    playerName = playerName,
    class = className,
    classKey = classKey,
    churchRank = rankTitle,
    record = record,
    honorifics = honorifics,
    latestCeremony = latestCeremony,
    latestMoment = latestMoment,
  }
end

local function setShown(widget, shown)
  if not widget then return end
  if shown then
    if widget.Show then widget:Show() end
  elseif widget.Hide then
    widget:Hide()
  end
end

local function paintOverview(frame)
  local model = overviewModel()
  frame.TitleText:SetText(model.guildName)
  frame.PageTitle:SetText("Church Overview")
  frame.IdentityTitle:SetText("Your Place")
  frame.OverviewGuildName:SetText(model.guildName)
  frame.OverviewStateValue:SetText(model.state)
  frame.OverviewDecreeLine:SetText(model.decreeLine)
  frame.OverviewDecreeFlavor:SetText(model.decreeFlavor)
  local height = frame.GetHeight and frame:GetHeight()
  local showFlavor = type(height) == "number" and height >= 460 and model.decreeFlavor ~= ""
  setShown(frame.OverviewDecreeFlavor, showFlavor)
  frame.OverviewRosterValue:SetText(model.roster)
  frame.OverviewCeremoniesValue:SetText(model.ceremonies)
  frame.OverviewGorasValue:SetText(model.goras)
  frame.OverviewMomentsValue:SetText(model.moments)
  frame.OverviewPlayerName:SetText(model.playerName)
  applyInk(frame.OverviewPlayerName, "gold")
  local cr, cg, cb
  if COB.Theme and type(COB.Theme.ClassColor) == "function" then
    cr, cg, cb = COB.Theme:ClassColor(model.classKey)
  end
  if type(cr) == "number" and frame.OverviewPlayerName.SetTextColor then
    frame.OverviewPlayerName:SetTextColor(cr, cg, cb, 1)
  end
  frame.OverviewPlayerClass:SetText(model.class)
  frame.OverviewRankValue:SetText(model.churchRank)
  frame.OverviewGuildRoleValue:SetText(model.guildRole)
  frame.OverviewRecordValue:SetText(model.record)
  frame.OverviewHonorificsValue:SetText(model.honorifics)
  frame.OverviewLatestLine:SetText("Ceremony — " .. model.latestCeremony)
  frame.OverviewLatestDetail:SetText("Marked moment — " .. model.latestMoment)
end

local function paint()
  local frame = RecordsBook.frame
  if not frame then return end
  local isOverview = pageIndex == 0
  setShown(frame.PrevButton, not isOverview)
  setShown(frame.NextButton, not isOverview)
  local activeRibbon = frame.VictoriesRibbon
  if isOverview then
    activeRibbon = frame.HomeRibbon
  elseif pageIndex == 5 then
    activeRibbon = frame.RivalriesRibbon
  elseif pageIndex == 8 then
    activeRibbon = frame.MartyrsRibbon
  end
  for _, button in ipairs({
    frame.HomeRibbon, frame.VictoriesRibbon, frame.RivalriesRibbon, frame.MartyrsRibbon,
  }) do
    if button and button._cobPlate then
      fillRole(button._cobPlate, button == activeRibbon and "oxblood" or "charcoal", 1)
    end
  end
  if type(frame.OverviewWidgets) == "table" then
    for i = 1, #frame.OverviewWidgets do setShown(frame.OverviewWidgets[i], isOverview) end
  end
  for _, widget in ipairs({
    frame.Body, frame.HonorificsHeading, frame.Honorifics,
    frame.MomentsHeading, frame.Moments,
  }) do
    setShown(widget, not isOverview)
  end
  if isOverview then
    if type(frame.Medallions) == "table" then
      for i = 1, #frame.Medallions do setShown(frame.Medallions[i], false) end
    end
    paintOverview(frame)
    return
  end
  local pages = buildPages()
  local n = #pages
  if pageIndex < 1 then pageIndex = 1 end
  if n >= 1 and pageIndex > n then pageIndex = n end
  local page = pages[pageIndex]
  if frame.IdentityTitle and frame.IdentityTitle.SetText then
    frame.IdentityTitle:SetText("Your Record")
  end
  if frame.TitleText then
    applyFont(frame.TitleText, "GameFontNormalHuge", "display", 26)
    applyInk(frame.TitleText, "gold")
    frame.TitleText:SetText("The Records Book")
  end
  if frame.PageTitle and frame.PageTitle.SetText then
    applyFont(frame.PageTitle, "GameFontNormalLarge", "label", 20)
    applyInk(frame.PageTitle, "oxblood")
    frame.PageTitle:SetText(page and page.title or "")
  end
  if frame.Body and frame.Body.SetText then
    applyFont(frame.Body, "GameFontNormal", "body", 14)
    applyInk(frame.Body, "charcoal")
    frame.Body:SetText(bodyText(page))
  end
  if frame.Honorifics and frame.Honorifics.SetText then
    applyFont(frame.Honorifics, "GameFontNormal", "body", 14)
    applyInk(frame.Honorifics, "charcoal")
    frame.Honorifics:SetText(identityText(localHonorifics()))
  end
  if frame.Moments and frame.Moments.SetText then
    applyFont(frame.Moments, "GameFontNormal", "body", 14)
    applyInk(frame.Moments, "charcoal")
    frame.Moments:SetText(identityText(momentLines()))
  end
  -- Fixed medallion pool: show one slot per entry. Never mint frames here.
  local slots = frame.Medallions
  local entries = page and page.entries
  local entryCount = (type(entries) == "table") and #entries or 0
  if type(slots) == "table" then
    for i = 1, #slots do
      local slot = slots[i]
      if slot then
        if i <= entryCount then
          dressMedallion(slot)
          if slot.Show then slot:Show() end
        elseif slot.Hide then
          slot:Hide()
        end
      end
    end
  end
end

local function turn(delta)
  local n = #PAGE_TITLES
  local nextIndex = pageIndex + delta
  if nextIndex < 0 then nextIndex = 0 end
  if nextIndex > n then nextIndex = n end
  pageIndex = nextIndex
  paint()
end

-- Wheel up Previous, wheel down Next. Shared by the outer frame and chrome
-- that sits on top of it (TitleBar, Close, ribbons, Previous, Next).
local function onMouseWheel(_, delta)
  if type(delta) ~= "number" then return end
  if delta > 0 then
    turn(-1)
  elseif delta < 0 then
    turn(1)
  end
end

local function wireChildWheel(child)
  if not child then return end
  if type(child.EnableMouseWheel) == "function" then
    child:EnableMouseWheel(true)
  end
  if type(child.SetScript) == "function" then
    child:SetScript("OnMouseWheel", onMouseWheel)
  end
end

local function jumpToTitle(title)
  for i = 1, #PAGE_TITLES do
    if PAGE_TITLES[i] == title then
      pageIndex = i
      paint()
      return
    end
  end
end

local function jumpHome()
  pageIndex = 0
  paint()
end

local function rememberSpecial(name)
  if type(UISpecialFrames) ~= "table" then return end
  for i = 1, #UISpecialFrames do
    if UISpecialFrames[i] == name then return end
  end
  UISpecialFrames[#UISpecialFrames + 1] = name
end

-- ESC Hide via UISpecialFrames bypasses RecordsBook:Hide. Restore a
-- missing OnHide; never replace an existing script. Remount
-- rememberSpecial so ESC still re-lists. Do not reset pageIndex.
-- Do not wire OnShow.
local function wireBookOnHide(widget)
  if not widget then return end
  if type(widget.SetScript) ~= "function" then return end
  local existing = type(widget.GetScript) == "function" and widget:GetScript("OnHide")
  if existing then return end
  widget:SetScript("OnHide", function()
    rememberSpecial(FRAME_NAME)
  end)
end

local function uiSlot()
  if type(ChurchOfBeefDB) ~= "table" then return nil end
  if type(ChurchOfBeefDB.ui) ~= "table" then return nil end
  if type(ChurchOfBeefDB.ui.recordsBook) ~= "table" then
    ChurchOfBeefDB.ui.recordsBook = {}
  end
  return ChurchOfBeefDB.ui.recordsBook
end

local TOME_MIN_W, TOME_MIN_H = 620, 500
local TOME_DEFAULT_W, TOME_DEFAULT_H = 680, 520
local TOME_LAYOUT_VERSION = 2
local TOME_MARGIN = 40

local function parentWH()
  local parent = UIParent
  local w = parent and parent.GetWidth and parent:GetWidth()
  local h = parent and parent.GetHeight and parent:GetHeight()
  if type(w) ~= "number" or w <= 0 then w = nil end
  if type(h) ~= "number" or h <= 0 then h = nil end
  return w, h
end

local function clampTomeSize(w, h)
  if type(w) ~= "number" or w ~= w then w = TOME_DEFAULT_W end
  if type(h) ~= "number" or h ~= h then h = tomeHeight() end
  if w < TOME_MIN_W then w = TOME_MIN_W end
  if h < TOME_MIN_H then h = TOME_MIN_H end
  local pw, ph = parentWH()
  if pw then w = math.min(w, math.max(TOME_MIN_W, pw - TOME_MARGIN)) end
  if ph then h = math.min(h, math.max(TOME_MIN_H, ph - TOME_MARGIN)) end
  return math.floor(w + 0.5), math.floor(h + 0.5)
end

local function savePoint(frame)
  local slot = uiSlot()
  if not slot then return end
  local point, _, relativePoint, x, y = frame:GetPoint(1)
  if type(point) ~= "string" or type(x) ~= "number" or type(y) ~= "number" then return end
  slot.point = { point = point, relativePoint = relativePoint or point, x = x, y = y }
end

local function saveSize(frame)
  local slot = uiSlot()
  if not slot or not frame then return end
  local w, h = frame:GetWidth(), frame:GetHeight()
  if type(w) ~= "number" or type(h) ~= "number" then return end
  w, h = clampTomeSize(w, h)
  slot.w = w
  slot.h = h
end

local function restoreSize(frame)
  if not frame then return end
  local slot = uiSlot()
  local w, h = TOME_DEFAULT_W, TOME_DEFAULT_H
  if type(slot) == "table" and slot.layoutVersion == TOME_LAYOUT_VERSION then
    if type(slot.w) == "number" then w = slot.w end
    if type(slot.h) == "number" then h = slot.h end
  end
  w, h = clampTomeSize(w, h)
  frame:SetWidth(w)
  frame:SetHeight(h)
  if type(slot) == "table" then
    slot.layoutVersion = TOME_LAYOUT_VERSION
    slot.w, slot.h = w, h
  end
end

local function applyTomeBounds(frame)
  if not frame then return end
  local pw, ph = parentWH()
  local maxW = pw and math.max(TOME_MIN_W, pw - TOME_MARGIN) or 1200
  local maxH = ph and math.max(TOME_MIN_H, ph - TOME_MARGIN) or 1200
  if type(frame.SetResizeBounds) == "function" then
    frame:SetResizeBounds(TOME_MIN_W, TOME_MIN_H, maxW, maxH)
  else
    if type(frame.SetMinResize) == "function" then
      frame:SetMinResize(TOME_MIN_W, TOME_MIN_H)
    end
    if type(frame.SetMaxResize) == "function" then
      frame:SetMaxResize(maxW, maxH)
    end
  end
end

local function onTomeSizeChanged(frame)
  if not frame or frame._cobClamping then return end
  local w, h = frame:GetWidth(), frame:GetHeight()
  local cw, ch = clampTomeSize(w, h)
  if cw ~= w or ch ~= h then
    frame._cobClamping = true
    frame:SetWidth(cw)
    frame:SetHeight(ch)
    frame._cobClamping = false
  end
end

local ANCHORS = {
  TOPLEFT = true, TOP = true, TOPRIGHT = true,
  LEFT = true, CENTER = true, RIGHT = true,
  BOTTOMLEFT = true, BOTTOM = true, BOTTOMRIGHT = true,
}

local function restorePoint(frame)
  local slot = uiSlot()
  local p = slot and slot.point
  frame:ClearAllPoints()
  local relative = type(p) == "table" and (p.relativePoint or p.point) or nil
  if type(p) == "table" and ANCHORS[p.point] and ANCHORS[relative]
      and type(p.x) == "number" and type(p.y) == "number" then
    frame:SetPoint(p.point, UIParent, relative, p.x, p.y)
  else
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
  end
end

local function buildFrame()
  local frame = CreateFrame("Frame", FRAME_NAME, UIParent)
  frame:SetFrameStrata("DIALOG")
  if frame.SetToplevel then frame:SetToplevel(true) end
  frame:EnableMouse(true)
  frame:SetMovable(true)
  frame:SetResizable(true)
  frame:SetClampedToScreen(true)
  if type(frame.EnableMouseWheel) == "function" then
    frame:EnableMouseWheel(true)
  end
  if type(frame.SetScript) == "function" then
    frame:SetScript("OnMouseWheel", onMouseWheel)
  end
  frame:SetWidth(TOME_DEFAULT_W)
  frame:SetHeight(TOME_DEFAULT_H)
  restoreSize(frame)
  applyTomeBounds(frame)
  frame:Hide()

  -- After the initial Hide so create does not fire OnHide remount.
  wireBookOnHide(frame)

  local sm = space("sm", 8)
  local md = space("md", 16)
  local xs = space("xs", 4)
  local lg = space("lg", 24)
  local xl = space("xl", 32)
  local ruleH = space("rule", 2)
  local bandH = 56
  local footerH = 48
  local sealPx = 40
  local tabW = 88
  local tabPitch = tabW + sm

  local iron = frame:CreateTexture(nil, "BACKGROUND")
  iron:SetAllPoints(frame)
  fillRole(iron, "iron", 0.96)
  frame.Iron = iron

  local gold = frame:CreateTexture(nil, "BORDER")
  gold:SetPoint("TOPLEFT", frame, "TOPLEFT", ruleH, -ruleH)
  gold:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -ruleH, ruleH)
  fillRole(gold, "gold", 1)
  frame.GoldEdge = gold

  local titleBand = frame:CreateTexture(nil, "ARTWORK")
  titleBand:SetPoint("TOPLEFT", frame, "TOPLEFT", xs, -xs)
  titleBand:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -xs, -xs)
  if titleBand.SetHeight then titleBand:SetHeight(bandH) end
  fillRole(titleBand, "charcoal")
  frame.TitleBand = titleBand

  local footerBand = frame:CreateTexture(nil, "ARTWORK")
  footerBand:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", xs, xs)
  footerBand:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -xs, xs)
  if footerBand.SetHeight then footerBand:SetHeight(footerH) end
  fillRole(footerBand, "charcoal")
  frame.FooterBand = footerBand

  -- Opaque parchment under each leaf so letterboxed tome art cannot
  -- show the gold plate through its margin.
  local leftFill = frame:CreateTexture(nil, "ARTWORK")
  leftFill:SetPoint("TOPLEFT", titleBand, "BOTTOMLEFT", 0, 0)
  leftFill:SetPoint("BOTTOMLEFT", footerBand, "TOPLEFT", 0, 0)
  leftFill:SetPoint("RIGHT", frame, "CENTER", -1, 0)
  fillRole(leftFill, "parchment", 1)
  if leftFill.SetDrawLayer then leftFill:SetDrawLayer("ARTWORK", 0) end
  frame.LeftLeafFill = leftFill

  -- Leaves sit flush under the boards and meet at the gutter (±1).
  local parchment = frame:CreateTexture(nil, "ARTWORK")
  parchment:SetPoint("TOPLEFT", titleBand, "BOTTOMLEFT", 0, 0)
  parchment:SetPoint("BOTTOMLEFT", footerBand, "TOPLEFT", 0, 0)
  parchment:SetPoint("RIGHT", frame, "CENTER", -1, 0)
  applyParchment(parchment)
  if parchment.SetDrawLayer then parchment:SetDrawLayer("ARTWORK", 1) end
  frame.Parchment = parchment

  local rightFill = frame:CreateTexture(nil, "ARTWORK")
  rightFill:SetPoint("TOPRIGHT", titleBand, "BOTTOMRIGHT", 0, 0)
  rightFill:SetPoint("BOTTOMRIGHT", footerBand, "TOPRIGHT", 0, 0)
  rightFill:SetPoint("LEFT", frame, "CENTER", 1, 0)
  fillRole(rightFill, "parchment", 1)
  if rightFill.SetDrawLayer then rightFill:SetDrawLayer("ARTWORK", 0) end
  frame.RightLeafFill = rightFill

  local rightLeaf = frame:CreateTexture(nil, "ARTWORK")
  rightLeaf:SetPoint("TOPRIGHT", titleBand, "BOTTOMRIGHT", 0, 0)
  rightLeaf:SetPoint("BOTTOMRIGHT", footerBand, "TOPRIGHT", 0, 0)
  rightLeaf:SetPoint("LEFT", frame, "CENTER", 1, 0)
  applyParchment(rightLeaf)
  if rightLeaf.SetDrawLayer then rightLeaf:SetDrawLayer("ARTWORK", 1) end
  frame.RightLeaf = rightLeaf

  local gutter = frame:CreateTexture(nil, "OVERLAY")
  gutter:SetWidth(ruleH)
  gutter:SetPoint("TOP", titleBand, "BOTTOM", 0, 0)
  gutter:SetPoint("BOTTOM", footerBand, "TOP", 0, 0)
  fillRole(gutter, "gold", 1)
  frame.Gutter = gutter

  local seal = frame:CreateTexture(nil, "OVERLAY")
  applyTexture(seal, "seal_papal")
  local sr, sg, sb = themeColor("gold")
  if type(sr) == "number" and seal.SetVertexColor then
    seal:SetVertexColor(sr, sg, sb, 1)
  end
  seal._cobColorRole = "gold"
  seal:SetWidth(sealPx)
  seal:SetHeight(sealPx)
  seal:SetPoint("LEFT", titleBand, "LEFT", md, 0)
  frame.Seal = seal

  local close = CreateFrame("Button", nil, frame)
  close:SetWidth(xl + lg)
  close:SetHeight(lg)
  close:SetPoint("RIGHT", titleBand, "RIGHT", -sm, 0)
  labelButton(close, "Close")
  close:SetScript("OnClick", function() RecordsBook:Hide() end)
  frame.CloseButton = close

  local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
  title:SetPoint("LEFT", seal, "RIGHT", sm, 0)
  title:SetPoint("RIGHT", close, "LEFT", -sm, 0)
  if title.SetJustifyH then title:SetJustifyH("CENTER") end
  if title.SetWordWrap then title:SetWordWrap(false) end
  applyFont(title, "GameFontNormalHuge", "display", 26)
  applyInk(title, "gold")
  title:SetText("The Records Book")
  frame.TitleText = title

  local pageTitle = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  pageTitle:SetPoint("TOPLEFT", parchment, "TOPLEFT", md, -md)
  pageTitle:SetPoint("RIGHT", parchment, "RIGHT", -md, 0)
  applyFont(pageTitle, "GameFontNormalLarge", "label", 20)
  applyInk(pageTitle, "oxblood")
  if pageTitle.SetJustifyH then pageTitle:SetJustifyH("LEFT") end
  pageTitle:SetText("")
  frame.PageTitle = pageTitle

  local rule = frame:CreateTexture(nil, "OVERLAY")
  rule:SetHeight(ruleH)
  rule:SetPoint("TOPLEFT", pageTitle, "BOTTOMLEFT", 0, -sm)
  rule:SetPoint("RIGHT", parchment, "RIGHT", -md, 0)
  fillRole(rule, "gold", 1)
  frame.TitleRule = rule

  local body = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  body:SetPoint("TOPLEFT", rule, "BOTTOMLEFT", lg, -md)
  body:SetPoint("RIGHT", parchment, "RIGHT", -md, 0)
  body:SetPoint("BOTTOM", footerBand, "TOP", 0, sm)
  applyFont(body, "GameFontNormal", "body", 14)
  applyInk(body, "charcoal")
  if body.SetJustifyH then body:SetJustifyH("LEFT") end
  if body.SetJustifyV then body:SetJustifyV("TOP") end
  if body.SetWordWrap then body:SetWordWrap(true) end
  if body.SetMaxLines then body:SetMaxLines(MEDALLION_POOL) end
  body:SetText("")
  frame.Body = body

  -- Right leaf is identity, not a tenth superlative page (§12.1 / §14.2 / §15).
  -- Static section labels keep the honest empty state readable instead of
  -- presenting a blank parchment spread before the first recorded ceremony.
  local identityTitle = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  identityTitle:SetPoint("TOPLEFT", rightLeaf, "TOPLEFT", md, -md)
  identityTitle:SetPoint("RIGHT", rightLeaf, "RIGHT", -md, 0)
  applyFont(identityTitle, "GameFontNormalLarge", "label", 20)
  applyInk(identityTitle, "oxblood")
  if identityTitle.SetJustifyH then identityTitle:SetJustifyH("LEFT") end
  identityTitle:SetText("Your Record")
  frame.IdentityTitle = identityTitle

  local identityRule = frame:CreateTexture(nil, "OVERLAY")
  identityRule:SetHeight(ruleH)
  identityRule:SetPoint("TOPLEFT", identityTitle, "BOTTOMLEFT", 0, -sm)
  identityRule:SetPoint("RIGHT", rightLeaf, "RIGHT", -md, 0)
  fillRole(identityRule, "gold", 1)
  frame.IdentityRule = identityRule

  local honorificsHeading = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  honorificsHeading:SetPoint("TOPLEFT", identityRule, "BOTTOMLEFT", lg, -md)
  honorificsHeading:SetPoint("RIGHT", rightLeaf, "RIGHT", -md, 0)
  applyFont(honorificsHeading, "GameFontNormal", "label", 14)
  applyInk(honorificsHeading, "oxblood")
  if honorificsHeading.SetJustifyH then honorificsHeading:SetJustifyH("LEFT") end
  honorificsHeading:SetText("Honorifics")
  frame.HonorificsHeading = honorificsHeading

  local honorifics = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  honorifics:SetPoint("TOPLEFT", honorificsHeading, "BOTTOMLEFT", 0, -sm)
  honorifics:SetPoint("RIGHT", rightLeaf, "RIGHT", -md, 0)
  applyFont(honorifics, "GameFontNormal", "body", 14)
  applyInk(honorifics, "charcoal")
  if honorifics.SetJustifyH then honorifics:SetJustifyH("LEFT") end
  if honorifics.SetJustifyV then honorifics:SetJustifyV("TOP") end
  if honorifics.SetWordWrap then honorifics:SetWordWrap(true) end
  if honorifics.SetMaxLines then honorifics:SetMaxLines(4) end
  honorifics:SetText("")
  frame.Honorifics = honorifics

  local momentsHeading = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  momentsHeading:SetPoint("TOPLEFT", honorifics, "BOTTOMLEFT", 0, -lg)
  momentsHeading:SetPoint("RIGHT", rightLeaf, "RIGHT", -md, 0)
  applyFont(momentsHeading, "GameFontNormal", "label", 14)
  applyInk(momentsHeading, "oxblood")
  if momentsHeading.SetJustifyH then momentsHeading:SetJustifyH("LEFT") end
  momentsHeading:SetText("Marked moments")
  frame.MomentsHeading = momentsHeading

  local moments = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  moments:SetPoint("TOPLEFT", momentsHeading, "BOTTOMLEFT", 0, -sm)
  moments:SetPoint("RIGHT", rightLeaf, "RIGHT", -md, 0)
  moments:SetPoint("BOTTOM", footerBand, "TOP", 0, sm)
  applyFont(moments, "GameFontNormal", "body", 14)
  applyInk(moments, "charcoal")
  if moments.SetJustifyH then moments:SetJustifyH("LEFT") end
  if moments.SetJustifyV then moments:SetJustifyV("TOP") end
  if moments.SetWordWrap then moments:SetWordWrap(true) end
  if moments.SetMaxLines then moments:SetMaxLines(8) end
  moments:SetText("")
  frame.Moments = moments

  -- `/beef` home spread. This is player-opened Quiet identity/history, not an
  -- ambient dashboard: every value is derived from Runtime, Decree, Roster, or
  -- Store and the entire group is hidden while browsing archive pages.
  frame.OverviewWidgets = {}
  local function trackOverview(widget)
    frame.OverviewWidgets[#frame.OverviewWidgets + 1] = widget
    if widget.Hide then widget:Hide() end
    return widget
  end

  local function overviewText(parent, template, role, size, ink)
    local fs = parent:CreateFontString(nil, "OVERLAY", template)
    applyFont(fs, template, role, size)
    applyInk(fs, ink)
    if fs.SetJustifyH then fs:SetJustifyH("LEFT") end
    if fs.SetWordWrap then fs:SetWordWrap(true) end
    return trackOverview(fs)
  end

  local guildSeal = trackOverview(frame:CreateTexture(nil, "OVERLAY"))
  guildSeal:SetWidth(80)
  guildSeal:SetHeight(80)
  guildSeal:SetPoint("TOPLEFT", rule, "BOTTOMLEFT", md, -md)
  applyTexture(guildSeal, "seal_papal")
  frame.OverviewGuildSeal = guildSeal

  local guildName = overviewText(frame, "GameFontNormalHuge", "display", 24, "oxblood")
  guildName:SetPoint("TOPLEFT", guildSeal, "TOPRIGHT", sm, -xs)
  guildName:SetPoint("RIGHT", parchment, "RIGHT", -md, 0)
  if guildName.SetMaxLines then guildName:SetMaxLines(2) end
  guildName:SetText("")
  frame.OverviewGuildName = guildName

  local stateLabel = overviewText(frame, "GameFontNormal", "label", 13, "oxblood")
  stateLabel:SetPoint("LEFT", guildName, "LEFT", 0, 0)
  stateLabel:SetPoint("BOTTOM", guildSeal, "BOTTOM", 0, 24)
  stateLabel:SetText("CURRENT CHURCH STATE")
  frame.OverviewStateLabel = stateLabel

  local stateValue = overviewText(frame, "GameFontNormalLarge", "label", 18, "charcoal")
  stateValue:SetPoint("TOPLEFT", stateLabel, "BOTTOMLEFT", 0, -xs)
  stateValue:SetPoint("RIGHT", parchment, "RIGHT", -md, 0)
  stateValue:SetText("")
  frame.OverviewStateValue = stateValue

  local statePlate = trackOverview(frame:CreateTexture(nil, "ARTWORK"))
  statePlate:SetPoint("TOPLEFT", guildSeal, "BOTTOMLEFT", 0, -md)
  statePlate:SetPoint("RIGHT", parchment, "RIGHT", -md, 0)
  statePlate:SetHeight(96)
  fillRole(statePlate, "charcoal", 1)
  frame.OverviewStatePlate = statePlate

  local decreeHead = overviewText(frame, "GameFontNormal", "label", 13, "gold")
  decreeHead:SetPoint("TOPLEFT", statePlate, "TOPLEFT", md, -sm)
  decreeHead:SetText("ACTIVE DECREE")
  frame.OverviewDecreeHead = decreeHead

  local decreeLine = overviewText(frame, "GameFontNormalLarge", "body", 16, "parchment")
  decreeLine:SetPoint("TOPLEFT", decreeHead, "BOTTOMLEFT", 0, -sm)
  decreeLine:SetPoint("RIGHT", statePlate, "RIGHT", -md, 0)
  if decreeLine.SetMaxLines then decreeLine:SetMaxLines(2) end
  decreeLine:SetText("")
  frame.OverviewDecreeLine = decreeLine

  local decreeFlavor = overviewText(frame, "GameFontDisableSmall", "body", 13, "silver")
  decreeFlavor:SetPoint("BOTTOMLEFT", statePlate, "BOTTOMLEFT", md, sm)
  decreeFlavor:SetPoint("RIGHT", statePlate, "RIGHT", -md, 0)
  if decreeFlavor.SetMaxLines then decreeFlavor:SetMaxLines(1) end
  decreeFlavor:SetText("")
  frame.OverviewDecreeFlavor = decreeFlavor

  local archiveHead = overviewText(frame, "GameFontNormal", "label", 13, "oxblood")
  archiveHead:SetPoint("BOTTOMLEFT", parchment, "BOTTOMLEFT", md, 120)
  archiveHead:SetText("THE CHRONICLE")
  frame.OverviewArchiveHead = archiveHead

  local function metricCard(label)
    local card = trackOverview(frame:CreateTexture(nil, "ARTWORK"))
    card:SetHeight(44)
    fillRole(card, "charcoal", 1)
    local value = overviewText(frame, "GameFontNormalLarge", "display", 20, "parchment")
    value:SetPoint("LEFT", card, "LEFT", sm, 0)
    value:SetWidth(36)
    if value.SetJustifyH then value:SetJustifyH("CENTER") end
    value:SetText("0")
    local head = overviewText(frame, "GameFontNormalSmall", "label", 12, "gold")
    head:SetPoint("LEFT", value, "RIGHT", sm, 0)
    head:SetPoint("RIGHT", card, "RIGHT", -sm, 0)
    head:SetText(label)
    return card, value
  end

  local gorasCard, gorasValue = metricCard("GORAS")
  gorasCard:SetPoint("BOTTOMLEFT", parchment, "BOTTOMLEFT", md, md)
  gorasCard:SetPoint("RIGHT", parchment, "CENTER", -xs, 0)
  frame.OverviewGorasValue = gorasValue

  local momentsCard, momentsValue = metricCard("MOMENTS")
  momentsCard:SetPoint("BOTTOMRIGHT", parchment, "BOTTOMRIGHT", -md, md)
  momentsCard:SetPoint("LEFT", parchment, "CENTER", xs, 0)
  frame.OverviewMomentsValue = momentsValue

  local rosterCard, rosterValue = metricCard("ROSTER")
  rosterCard:SetPoint("BOTTOMLEFT", gorasCard, "TOPLEFT", 0, xs)
  rosterCard:SetPoint("RIGHT", gorasCard, "RIGHT", 0, 0)
  frame.OverviewRosterValue = rosterValue

  local ceremoniesCard, ceremoniesValue = metricCard("CEREMONIES")
  ceremoniesCard:SetPoint("BOTTOMLEFT", momentsCard, "TOPLEFT", 0, xs)
  ceremoniesCard:SetPoint("RIGHT", momentsCard, "RIGHT", 0, 0)
  frame.OverviewCeremoniesValue = ceremoniesValue

  local playerPlate = trackOverview(frame:CreateTexture(nil, "ARTWORK"))
  playerPlate:SetPoint("TOPLEFT", identityRule, "BOTTOMLEFT", md, -md)
  playerPlate:SetPoint("RIGHT", rightLeaf, "RIGHT", -md, 0)
  playerPlate:SetHeight(84)
  fillRole(playerPlate, "charcoal", 1)
  frame.OverviewPlayerPlate = playerPlate

  local playerSigil = trackOverview(frame:CreateTexture(nil, "OVERLAY"))
  playerSigil:SetWidth(64)
  playerSigil:SetHeight(72)
  playerSigil:SetPoint("RIGHT", playerPlate, "RIGHT", -sm, 0)
  applyTexture(playerSigil, "sigil_gora")
  frame.OverviewPlayerSigil = playerSigil

  local playerName = overviewText(frame, "GameFontNormalHuge", "display", 22, "gold")
  playerName:SetPoint("TOPLEFT", playerPlate, "TOPLEFT", md, -md)
  playerName:SetPoint("RIGHT", playerSigil, "LEFT", -sm, 0)
  if playerName.SetMaxLines then playerName:SetMaxLines(1) end
  playerName:SetText("")
  frame.OverviewPlayerName = playerName

  local playerClass = overviewText(frame, "GameFontDisableSmall", "body", 14, "parchment")
  playerClass:SetPoint("TOPLEFT", playerName, "BOTTOMLEFT", 0, -xs)
  playerClass:SetPoint("RIGHT", playerSigil, "LEFT", -sm, 0)
  playerClass:SetText("")
  frame.OverviewPlayerClass = playerClass

  local function profileCell(label)
    local head = overviewText(frame, "GameFontNormal", "label", 13, "oxblood")
    head:SetText(label)
    local value = overviewText(frame, "GameFontNormal", "body", 15, "charcoal")
    value:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -xs)
    if value.SetMaxLines then value:SetMaxLines(2) end
    value:SetText("")
    return head, value
  end

  local rankHead, rankValue = profileCell("CHURCH RANK")
  rankHead:SetPoint("TOPLEFT", playerPlate, "BOTTOMLEFT", 0, -md)
  rankHead:SetPoint("RIGHT", rightLeaf, "CENTER", -sm, 0)
  rankValue:SetPoint("RIGHT", rankHead, "RIGHT", 0, 0)
  frame.OverviewRankValue = rankValue

  local guildRoleHead, guildRoleValue = profileCell("GUILD ROLE")
  guildRoleHead:SetPoint("TOPLEFT", playerPlate, "BOTTOM", sm, -md)
  guildRoleHead:SetPoint("RIGHT", rightLeaf, "RIGHT", -md, 0)
  guildRoleValue:SetPoint("RIGHT", guildRoleHead, "RIGHT", 0, 0)
  frame.OverviewGuildRoleValue = guildRoleValue

  local recordHead, recordValue = profileCell("SANCTIONED GORA")
  recordHead:SetPoint("TOPLEFT", rankValue, "BOTTOMLEFT", 0, -lg)
  recordHead:SetPoint("RIGHT", rankHead, "RIGHT", 0, 0)
  recordValue:SetPoint("RIGHT", recordHead, "RIGHT", 0, 0)
  frame.OverviewRecordValue = recordValue

  local honorificsHead, honorificsValue = profileCell("HONORIFICS")
  honorificsHead:SetPoint("TOPLEFT", guildRoleValue, "BOTTOMLEFT", 0, -lg)
  honorificsHead:SetPoint("RIGHT", guildRoleHead, "RIGHT", 0, 0)
  honorificsValue:SetPoint("RIGHT", honorificsHead, "RIGHT", 0, 0)
  frame.OverviewHonorificsValue = honorificsValue

  local latestPlate = trackOverview(frame:CreateTexture(nil, "ARTWORK"))
  latestPlate:SetPoint("BOTTOMLEFT", rightLeaf, "BOTTOMLEFT", md, md)
  latestPlate:SetPoint("RIGHT", rightLeaf, "RIGHT", -md, 0)
  latestPlate:SetHeight(88)
  fillRole(latestPlate, "iron", 1)
  frame.OverviewLatestPlate = latestPlate

  local latestHead = overviewText(frame, "GameFontNormal", "label", 13, "gold")
  latestHead:SetPoint("TOPLEFT", latestPlate, "TOPLEFT", md, -sm)
  latestHead:SetText("LATEST CHRONICLE")
  frame.OverviewLatestHead = latestHead

  local latestLine = overviewText(frame, "GameFontNormalLarge", "body", 16, "parchment")
  latestLine:SetPoint("TOPLEFT", latestHead, "BOTTOMLEFT", 0, -sm)
  latestLine:SetPoint("RIGHT", latestPlate, "RIGHT", -md, 0)
  if latestLine.SetMaxLines then latestLine:SetMaxLines(1) end
  latestLine:SetText("")
  frame.OverviewLatestLine = latestLine

  local latestDetail = overviewText(frame, "GameFontDisableSmall", "body", 13, "silver")
  latestDetail:SetPoint("TOPLEFT", latestLine, "BOTTOMLEFT", 0, -xs)
  latestDetail:SetPoint("RIGHT", latestPlate, "RIGHT", -md, 0)
  if latestDetail.SetMaxLines then latestDetail:SetMaxLines(1) end
  latestDetail:SetText("")
  frame.OverviewLatestDetail = latestDetail

  -- Entry medallions: fixed pool. paint() shows/hides; never rebuilds.
  -- Sit in the left-leaf gutter, one stride per body line.
  frame.Medallions = {}
  for i = 1, MEDALLION_POOL do
    local slot = frame:CreateTexture(nil, "OVERLAY")
    dressMedallion(slot)
    slot:SetWidth(md)
    slot:SetHeight(md)
    slot:SetPoint("TOPRIGHT", body, "TOPLEFT", -sm, -(i - 1) * lg)
    if slot.Hide then slot:Hide() end
    frame.Medallions[i] = slot
  end
  frame.Medallion = frame.Medallions[1]

  local titleBar = CreateFrame("Frame", nil, frame)
  titleBar:SetPoint("TOPLEFT", titleBand, "TOPLEFT", sm, 0)
  titleBar:SetPoint("TOPRIGHT", titleBand, "TOPRIGHT", -xl, 0)
  titleBar:SetHeight(bandH)
  titleBar:EnableMouse(true)
  titleBar:RegisterForDrag("LeftButton")
  titleBar:SetScript("OnDragStart", function() frame:StartMoving() end)
  titleBar:SetScript("OnDragStop", function()
    frame:StopMovingOrSizing()
    savePoint(frame)
    saveSize(frame)
  end)
  frame.TitleBar = titleBar

  local function addRibbon(label, title)
    local btn = CreateFrame("Button", nil, frame)
    btn:SetWidth(tabW)
    btn:SetHeight(xl)
    labelButton(btn, label)
    btn:SetScript("OnClick", function() jumpToTitle(title) end)
    return btn
  end

  local homeRibbon = CreateFrame("Button", nil, frame)
  homeRibbon:SetWidth(tabW)
  homeRibbon:SetHeight(xl)
  labelButton(homeRibbon, "HOME")
  homeRibbon:SetScript("OnClick", jumpHome)
  homeRibbon:SetPoint("CENTER", footerBand, "CENTER", -tabPitch * 1.5, 0)
  dressRibbon(homeRibbon)
  frame.HomeRibbon = homeRibbon

  local victoriesRibbon = addRibbon("RECORDS", "Most Sanctioned Victories")
  victoriesRibbon:SetPoint("CENTER", footerBand, "CENTER", -tabPitch * 0.5, 0)
  dressRibbon(victoriesRibbon)
  frame.VictoriesRibbon = victoriesRibbon

  local rivalriesRibbon = addRibbon("RIVALRIES", "Greatest Rivalry")
  rivalriesRibbon:SetPoint("CENTER", footerBand, "CENTER", tabPitch * 0.5, 0)
  dressRibbon(rivalriesRibbon)
  frame.RivalriesRibbon = rivalriesRibbon

  local martyrsRibbon = addRibbon("MARTYRS", "The Glorious Martyr")
  martyrsRibbon:SetPoint("CENTER", footerBand, "CENTER", tabPitch * 1.5, 0)
  dressRibbon(martyrsRibbon)
  frame.MartyrsRibbon = martyrsRibbon

  local prev = CreateFrame("Button", nil, frame)
  prev:SetWidth(64)
  prev:SetHeight(xl)
  prev:SetPoint("LEFT", footerBand, "LEFT", md, 0)
  labelButton(prev, "PREV")
  prev:SetScript("OnClick", function() turn(-1) end)
  frame.PrevButton = prev

  local nextBtn = CreateFrame("Button", nil, frame)
  nextBtn:SetWidth(64)
  nextBtn:SetHeight(xl)
  nextBtn:SetPoint("RIGHT", footerBand, "RIGHT", -md, 0)
  labelButton(nextBtn, "NEXT")
  nextBtn:SetScript("OnClick", function() turn(1) end)
  frame.NextButton = nextBtn

  wireChildWheel(frame.TitleBar)
  wireChildWheel(frame.CloseButton)
  wireChildWheel(frame.HomeRibbon)
  wireChildWheel(frame.VictoriesRibbon)
  wireChildWheel(frame.RivalriesRibbon)
  wireChildWheel(frame.MartyrsRibbon)
  wireChildWheel(frame.PrevButton)
  wireChildWheel(frame.NextButton)

  local grip = CreateFrame("Button", nil, frame)
  grip:SetWidth(18)
  grip:SetHeight(18)
  grip:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -3, 3)
  grip:EnableMouse(true)
  grip:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  local gripPlate = grip:CreateTexture(nil, "ARTWORK")
  if gripPlate.SetAllPoints then gripPlate:SetAllPoints(grip) end
  fillRole(gripPlate, "iron")
  local gripRim = grip:CreateTexture(nil, "OVERLAY")
  gripRim:SetPoint("TOPLEFT", grip, "TOPLEFT", 1, -1)
  gripRim:SetPoint("BOTTOMRIGHT", grip, "BOTTOMRIGHT", -1, 1)
  fillRole(gripRim, "gold")
  grip:SetScript("OnMouseDown", function(_, button)
    if button == "RightButton" then
      frame:SetWidth(TOME_DEFAULT_W)
      frame:SetHeight(TOME_DEFAULT_H)
      saveSize(frame)
      return
    end
    if type(frame.StartSizing) == "function" then
      frame:StartSizing("BOTTOMRIGHT")
    end
  end)
  grip:SetScript("OnMouseUp", function()
    if type(frame.StopMovingOrSizing) == "function" then
      frame:StopMovingOrSizing()
    end
    savePoint(frame)
    saveSize(frame)
  end)
  frame.SizeGrip = grip
  if type(frame.HookScript) == "function" then
    frame:HookScript("OnSizeChanged", function()
      onTomeSizeChanged(frame)
      if pageIndex == 0 and frame:IsShown() then paint() end
    end)
  elseif type(frame.SetScript) == "function" then
    frame:SetScript("OnSizeChanged", function() onTomeSizeChanged(frame) end)
  end
  if type(frame.RegisterEvent) == "function" then
    frame:RegisterEvent("DISPLAY_SIZE_CHANGED")
    frame:RegisterEvent("UI_SCALE_CHANGED")
    if type(frame.HookScript) == "function" then
      frame:HookScript("OnEvent", function()
        applyTomeBounds(frame)
        onTomeSizeChanged(frame)
      end)
    end
  end

  restorePoint(frame)
  rememberSpecial(FRAME_NAME)
  return frame
end

function RecordsBook:ResetForTests()
  if not COB._IN_TEST then return false end
  pageIndex = 1
  if self.frame then self.frame:Hide() end
  return true
end

function RecordsBook:Init()
  if self.frame then
    wireBookOnHide(self.frame)
    rememberSpecial(FRAME_NAME)
    return self.frame
  end
  if type(CreateFrame) ~= "function" then return nil end
  self.frame = buildFrame()
  return self.frame
end

function RecordsBook:IsShown()
  return self.frame and self.frame:IsShown() and true or false
end

function RecordsBook:Show()
  local frame = self:Init()
  if not frame then return false end
  wireBookOnHide(frame)
  paint()
  frame:Show()
  return true
end

function RecordsBook:Hide()
  if self.frame then
    wireBookOnHide(self.frame)
    rememberSpecial(FRAME_NAME)
    self.frame:Hide()
  end
  return true
end

function RecordsBook:Toggle()
  if self:IsShown() then
    return self:Hide()
  end
  return self:Show()
end

function RecordsBook:ShowHome()
  pageIndex = 0
  if COB.Roster and type(COB.Roster.Refresh) == "function" then
    pcall(COB.Roster.Refresh, COB.Roster)
  end
  return self:Show()
end

function RecordsBook:ToggleHome()
  if self:IsShown() then
    -- `/beef` on an archive leaf returns to the frontispiece. Only a second
    -- `/beef` from the frontispiece closes the book.
    if pageIndex ~= 0 then return self:ShowHome() end
    return self:Hide()
  end
  return self:ShowHome()
end

function RecordsBook:GetOverview()
  return deepcopy(overviewModel())
end

function RecordsBook:GetPages()
  return deepcopy(buildPages())
end
